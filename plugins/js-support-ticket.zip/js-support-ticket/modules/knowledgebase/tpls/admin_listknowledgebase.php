<span class="js-adminhead-title"><a class="jsanchor-backlink" href="<?php echo admin_url('admin.php?page=jssupportticket&jstlay=controlpanel');?>"><img src="<?php echo jssupportticket::$_pluginpath; ?>includes/images/back-icon.png" /></a><span class="jsheadtext"><?php echo __('Knowledge Base', 'js-support-ticket'); ?></span>
</span>
<div class="js-wrapper">
    <div class="js-box-wrapper js-1">
        <a class="js-admin-link" href="?page=knowledgebase&jstlay=addcategory"><div class="js-box"><div class="img-wrapper"><img style="width:50px;" src="<?php echo jssupportticket::$_pluginpath; ?>includes/images/addknowledgebasecategory.png"/></div><div class="text-wrapper"><?php echo __('Add Category', 'js-support-ticket'); ?></div></div></a>
        <a class="js-admin-link" href="?page=knowledgebase&jstlay=addarticle"><div class="js-box"><div class="img-wrapper"><img style="width:50px;" src="<?php echo jssupportticket::$_pluginpath; ?>includes/images/addknowledgebasearticle.png"/></div><div class="text-wrapper"><?php echo __('Add Knowledge Base', 'js-support-ticket'); ?></div></div></a>
        <a class="js-admin-link" href="?page=knowledgebase&jstlay=listcategories"><div class="js-box"><div class="img-wrapper"><img style="width:50px;" src="<?php echo jssupportticket::$_pluginpath; ?>includes/images/knowledgebasecategory.png"/></div><div class="text-wrapper"><?php echo __('Categories', 'js-support-ticket'); ?></div></div></a>
        <a class="js-admin-link" href="?page=knowledgebase&jstlay=listarticles"><div class="js-box"><div class="img-wrapper"><img style="width:50px;" src="<?php echo jssupportticket::$_pluginpath; ?>includes/images/knowledgebasearticle.png"/></div><div class="text-wrapper"><?php echo __('Knowledge Base', 'js-support-ticket'); ?></div></div></a>
    </div>
</div>
<?php
